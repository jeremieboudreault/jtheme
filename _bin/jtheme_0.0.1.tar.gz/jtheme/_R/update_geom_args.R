#'@export
update_geom_args <- function(x) {

    # Set default position to "dodge2" for histogram.
    formals(geom_histogram)$position <- ggplot2::position_dodge2(preserve = "single")
    formals(geom_histogram)$bins     <- 10

}
