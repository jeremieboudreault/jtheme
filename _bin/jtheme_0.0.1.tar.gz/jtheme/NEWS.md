News
================================================================================

To-do list : 

+ Change default histogram position to "dodge2" (tested using "formals()")
+ Change default number of bins to 12L
+ Mettre à jour les couleurs de `colors` avec des palettes.
+ "Source Sans Pro" est la police par défault, mais il faut valider si elle est dispo et la charger automatique avec extrafonts
+ Corriger la police par défaut dans geom_text()
+ Translate plots to English
+ Fix expand that does not allow to have a new scale_x or scale_y
