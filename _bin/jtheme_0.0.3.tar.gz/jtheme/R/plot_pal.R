# plot_pal.
plot_pal <- function(pal) {
    plot(
        x  = seq_along(pal),
        y  = rep(1L, length(pal)),
        col = pal,
        pch = 19,
        cex = 5
    )
}
